# Copyright 2004-2008 Roman Yakovenko.
# Distributed under the Boost Software License, Version 1.0. (See
# accompanying file LICENSE_1_0.txt or copy at
# http://www.boost.org/LICENSE_1_0.txt)

import unittest
import autoconfig
import parser_test_case

from pygccxml import utils
from pygccxml import parser
from pygccxml import declarations

class tester_t( parser_test_case.parser_test_case_t ):
    global_ns = None
    def __init__(self, *args ):
        parser_test_case.parser_test_case_t.__init__( self, *args )
        self.header = 'type_as_exception_bug.h'
        
    def setUp(self):
        if not tester_t.global_ns:
            decls = parser.parse( [self.header], self.config )
            tester_t.global_ns = declarations.get_global_namespace( decls )
            tester_t.global_ns.init_optimizer()

    def test( self ):                
        pass
        #~ buggy = self.global_ns.mem_fun( 'buggy' )
        #~ ExpressionError = self.global_ns.class_( 'ExpressionError' )
        #~ self.failUnless( len( buggy.exceptions ) == 1 )
        #~ err = buggy.exceptions[0]
        #~ self.failUnless( declarations.is_reference( err ) )
        #~ err = declarations.remove_declarated( declarations.remove_reference( err ) )
        #~ self.failUnless( err is ExpressionError )
        

def create_suite():
    suite = unittest.TestSuite()        
    suite.addTest( unittest.makeSuite(tester_t))
    return suite

def run_suite():
    unittest.TextTestRunner(verbosity=2).run( create_suite() )

if __name__ == "__main__":
    run_suite()

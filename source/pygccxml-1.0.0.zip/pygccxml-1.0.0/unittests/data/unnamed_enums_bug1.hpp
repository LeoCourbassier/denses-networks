// Copyright 2004-2008 Roman Yakovenko.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef __unnamed_enums_bug1_hpp__
#define __unnamed_enums_bug1_hpp__

enum{ x1, x2 };
enum{ y1, y2 };


#endif//__unnamed_enums_bug1_hpp__
